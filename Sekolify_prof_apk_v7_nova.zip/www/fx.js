// =====================================================================
//  Sekolify Prof - effets visuels (v8 "Nova")
//  Module purement décoratif : il ne lit ni n'écrit aucune donnée et n'appelle
//  aucune fonction de app.js. S'il échoue, l'application fonctionne comme avant.
//   - cascade d'entrée des listes à chaque changement d'écran / d'onglet
//   - ondulation au toucher sur les boutons
//   - pastille lumineuse glissante de la barre de navigation
//   - petit "rebond" des compteurs de présence quand ils changent
// =====================================================================
(function () {
    "use strict";
    try {
        const body = document.body;

        // --- 1. Cascade d'entrée : classe temporaire sur <body> ---------------
        let enterTimer = null;
        function triggerEnter() {
            body.classList.remove("fx-enter");
            void body.offsetWidth;                 // relance les animations CSS
            body.classList.add("fx-enter");
            clearTimeout(enterTimer);
            enterTimer = setTimeout(() => body.classList.remove("fx-enter"), 1500);
        }
        const viewObs = new MutationObserver(muts => {
            for (const m of muts) {
                const t = m.target;
                if (m.attributeName === "class" && t.classList.contains("view") && t.classList.contains("active") && !(m.oldValue || "").includes("active")) { triggerEnter(); return; }
                if (m.attributeName === "hidden" && t.tagName === "SECTION" && !t.hidden) { triggerEnter(); return; }
            }
        });
        document.querySelectorAll(".view").forEach(v => viewObs.observe(v, { attributes: true, attributeFilter: ["class"], attributeOldValue: true }));
        document.querySelectorAll("#view-main section").forEach(s => viewObs.observe(s, { attributes: true, attributeFilter: ["hidden"] }));
        triggerEnter();

        // --- 2. Ondulation au toucher -----------------------------------------
        const RIPPLE_SEL = ".btn-primary,.btn-sync,.btn-secondary,.btn-tool,.list-item,.appel-card,.seg-btn,.chip,.day-pill,.hour-chip,.nav-btn,.btn-icon,.banner-btn";
        document.addEventListener("pointerdown", e => {
            const el = e.target.closest && e.target.closest(RIPPLE_SEL);
            if (!el || el.disabled) return;
            const r = el.getBoundingClientRect();
            const size = Math.max(r.width, r.height) * 2;
            const s = document.createElement("span");
            s.className = "ripple";
            s.style.cssText = "width:" + size + "px;height:" + size + "px;left:" + (e.clientX - r.left - size / 2) + "px;top:" + (e.clientY - r.top - size / 2) + "px";
            el.appendChild(s);
            s.addEventListener("animationend", () => s.remove());
            setTimeout(() => s.remove(), 900);
        }, { passive: true });

        // --- 3. Pastille glissante de la navigation ---------------------------
        const glow = document.getElementById("nav-glow");
        const nav = document.querySelector(".bottom-nav");
        function placeGlow() {
            if (!glow || !nav) return;
            const a = nav.querySelector(".nav-btn.active");
            if (!a || !a.offsetWidth) return;
            glow.style.width = a.offsetWidth + "px";
            glow.style.transform = "translateX(" + a.offsetLeft + "px)";
        }
        if (nav) {
            new MutationObserver(placeGlow).observe(nav, { attributes: true, attributeFilter: ["class"], subtree: true });
            window.addEventListener("resize", placeGlow);
            const main = document.getElementById("view-main");
            if (main) new MutationObserver(placeGlow).observe(main, { attributes: true, attributeFilter: ["class"] });
            placeGlow(); setTimeout(placeGlow, 120);
        }

        // --- 4. Rebond des compteurs de présence ------------------------------
        const sum = document.getElementById("p-summary");
        if (sum) {
            let last = {};
            new MutationObserver(() => {
                const next = {};
                sum.querySelectorAll(".p-count").forEach(c => {
                    const b = c.querySelector("b"), label = (c.querySelector("span") || {}).textContent;
                    if (!b) return;
                    next[label] = b.textContent;
                    if (label in last && last[label] !== b.textContent) b.classList.add("bump");
                });
                last = next;
            }).observe(sum, { childList: true });
        }
    } catch (e) { /* effets facultatifs : on ignore toute erreur */ }
})();
