// =====================================================================
//  Sekolify Prof - application mobile des professeurs (v7)
//  - Le PC est trouvé automatiquement sur le Wi-Fi (pas d'adresse IP à saisir)
//  - Nouveau téléphone : port affiché sur le PC + validation par l'administration
//  - Notes ET présence saisies hors-ligne, envoyées au PC dès que le Wi-Fi le permet
//  - Présence : uniquement sur un créneau de l'emploi du temps du prof, de 10 min
//    avant le début du créneau jusqu'à sa fin ; correction possible le jour même
// =====================================================================

const DISCOVERY_PORT = 47831;      // port FIXE du PC (ne donne que l'adresse ; le port principal change)
const PREFIXES = ["192.168.43", "192.168.1", "192.168.0", "192.168.8", "192.168.100", "192.168.2",
                  "192.168.137", "10.0.0", "10.0.1", "172.20.10", "192.168.10", "192.168.3"];
const PRESENCE_KEY = "sekolify_presence";
const PRESENCE_KEEP_DAYS = 14;

// --- ETAT ---
let serverUrl = "";               // http://ip:port (port principal, change à chaque lancement du PC)
let teacherData = null;           // { classes, timetable, config, grades, attendance, server_now }
let nav = { cls: null, period: null, cs: null };
let baseGrades = {};              // notes connues du serveur  { clé: valeur }
let dirty = {};                   // notes modifiées non envoyées { clé: {entrée} }
let presenceStore = {};           // appels faits sur le téléphone { clé: appel }
let serverAtt = {};               // appels connus du serveur { clé: {by_me, records} }
let slotIndex = {};               // créneaux horaires affichés { clé: créneau }
let appel = null;                 // appel en cours d'affichage
let offlineMode = false;
let connectBusy = false;
let syncBusy = false;
let reconnectPromise = null;
let pendingTimer = null;
let pendingFails = 0;
let timetableDay = 0;
let mainTab = "home";

const DEFAULT_CONFIG = {
    school_name: "Sekolify", period_system: "TRIMESTRE", period_count: 3,
    ds_per_period: 3, weight_ds: 1, weight_exam: 2, max_score: 20, presence_early_minutes: 10
};
const DAY_NAMES = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
const DAYS_FULL = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
const MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];


// --- OUTILS ---
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function lsGet(key, fallback = null) {
    try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); } catch (e) { return fallback; }
}
function lsSet(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignoré */ } }
function lsDel(...keys) { keys.forEach(k => { try { localStorage.removeItem(k); } catch (e) { /* ignoré */ } }); }

function cfg() { return Object.assign({}, DEFAULT_CONFIG, (teacherData && teacherData.config) || {}); }
function periodLabel(p) { return (cfg().period_system === "BIMESTRE" ? "Bimestre " : "Trimestre ") + p; }
const gkey = (cs, st, period, type, index) => `${cs}|${st}|${period}|${type}|${index}`;
const dsIndexes = () => Array.from({ length: Math.max(1, cfg().ds_per_period) }, (_, i) => i + 1);

let toastTimer;
function showToast(msg, iconName) {
    const t = $("toast");
    t.innerHTML = (iconName ? icon(iconName, iconName === "loader-circle" ? "ic-spin" : "") : "") + esc(msg);
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 3200);
}

function deviceId() {
    let id = lsGet("sekolify_device_id");
    if (!id) {
        id = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
            : Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
        lsSet("sekolify_device_id", id);
    }
    return id;
}
function deviceName() {
    const m = /;\s*([^;)]+?)\s+Build\//.exec(navigator.userAgent || "");
    return m ? m[1] : "Téléphone Android";
}


// --- HEURES ET DATES (fonctions pures) ---
const pad2 = n => String(n).padStart(2, "0");
const hh = h => pad2(h) + ":00";
function dateStr(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function stampStr(d) { return `${dateStr(d)}T${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`; }
function weekdayIndex(d) { return (d.getDay() + 6) % 7; }                 // 0 = lundi ... 6 = dimanche
function todayIndex() { const w = weekdayIndex(new Date()); return w === 6 ? 0 : w; }   // pour l'affichage : dimanche -> lundi
function fmtMin(total) { return pad2(Math.floor(total / 60)) + ":" + pad2(total % 60); }
function earlyMin() { const v = Number(cfg().presence_early_minutes); return isFinite(v) && v >= 0 ? v : 10; }

// Fenêtre d'appel d'un créneau (heure h) : de h:00 - 10 min jusqu'à (h+1):00 exclu
function windowState(hour, now) {
    const m = now.getHours() * 60 + now.getMinutes();
    if (m < hour * 60 - earlyMin()) return "upcoming";
    return m < (hour + 1) * 60 ? "open" : "closed";
}

// --- NAVIGATION (le bouton Retour d'Android fonctionne) ---
const CONTENT_VIEWS = ["view-main", "view-periods", "view-notes", "view-presence"];
function show(viewId) {
    document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
    $(viewId).classList.add("active");
    $(viewId).scrollTop = 0;
}
function go(viewId) { history.pushState({ view: viewId }, ""); show(viewId); }
function goRoot(viewId) { history.replaceState({ view: viewId }, ""); show(viewId); }
function inContent() { return CONTENT_VIEWS.some(v => $(v).classList.contains("active")); }
function rootView() { return lsGet("sekolify_token") && teacherData ? "view-main" : "view-login"; }

window.addEventListener("popstate", e => {
    const v = (e.state && e.state.view) || rootView();
    if ($("view-presence").classList.contains("active") && appel && appel.dirty) {
        showToast("Appel non enregistré : les modifications sont perdues.", "triangle-alert");
        appel.dirty = false;
    }
    if (v === "view-periods") renderPeriods();
    if (v === "view-notes") renderNotesView();
    if (v === "view-main") renderMain();
    if (v === "view-presence") { if (!appel) { renderMain(); show("view-main"); return; } renderAppel(); }
    show(v);
});

// =====================================================================
//  RÉSEAU
// =====================================================================

// Requête HTTP avec vrai délai d'attente (plugin natif Capacitor si disponible, sinon fetch)
async function httpRequest(method, url, body, timeout = 8000, headers = {}) {
    const h = Object.assign(body !== undefined ? { "Content-Type": "application/json" } : {}, headers);
    const cap = window.Capacitor;
    const nativeHttp = cap && cap.Plugins && cap.Plugins.CapacitorHttp;
    if (nativeHttp && nativeHttp.request) {
        const r = await nativeHttp.request({ url, method, headers: h, data: body, connectTimeout: timeout, readTimeout: timeout, responseType: "json" });
        let data = r.data;
        if (typeof data === "string") { try { data = JSON.parse(data); } catch (e) { /* texte brut */ } }
        return { status: r.status, data };
    }
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeout);
    try {
        const res = await fetch(url, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined, signal: ctl.signal });
        let data = null;
        try { data = await res.json(); } catch (e) { /* pas de JSON */ }
        return { status: res.status, data };
    } finally { clearTimeout(timer); }
}

// Appel de l'API principale (avec jeton). Si le PC a été relancé (nouveau port), on le retrouve tout seul.
async function rawApi(method, path, body, timeout) {
    const token = lsGet("sekolify_token");
    return httpRequest(method, `${serverUrl}${path}`, body, timeout || 10000, token ? { Authorization: `Bearer ${token}` } : {});
}
async function api(method, path, body, timeout) {
    try {
        return await rawApi(method, path, body, timeout);
    } catch (err) {
        if (!lsGet("sekolify_token")) throw err;
        await reconnectSilently();            // lève une erreur si le PC reste introuvable
        return await rawApi(method, path, body, timeout);
    }
}

// --- Recherche du PC sur le Wi-Fi ---
async function probe(ip, timeout = 700) {
    try {
        const r = await httpRequest("GET", `http://${ip}:${DISCOVERY_PORT}/hello`, undefined, timeout);
        if (r.status === 200 && r.data && r.data.app === "sekolify") return r.data;
    } catch (e) { /* pas de PC ici */ }
    return null;
}

function getLocalIPv4s(timeout = 1200) {
    return new Promise(resolve => {
        const ips = new Set();
        let pc, finished = false;
        const done = () => { if (finished) return; finished = true; try { pc && pc.close(); } catch (e) { /* ok */ } resolve([...ips]); };
        try { pc = new RTCPeerConnection({ iceServers: [] }); } catch (e) { return resolve([]); }
        pc.createDataChannel("x");
        pc.onicecandidate = ev => {
            if (!ev.candidate) return done();
            const m = /\b((?:10|192\.168|172\.(?:1[6-9]|2\d|3[01]))(?:\.\d{1,3}){2,3})\b/.exec(ev.candidate.candidate);
            if (m) ips.add(m[1]);
        };
        pc.createOffer().then(o => pc.setLocalDescription(o)).catch(done);
        setTimeout(done, timeout);
    });
}

async function scanPrefix(prefix, onProgress) {
    let found = null, next = 1;
    const worker = async () => {
        while (!found && next <= 254) {
            const n = next++;
            const ip = `${prefix}.${n}`;
            const r = await probe(ip, 600);
            if (r && !found) found = ip;
        }
    };
    if (onProgress) onProgress(prefix);
    await Promise.all(Array.from({ length: 48 }, worker));
    return found;
}

// Renvoie l'adresse IP du PC, ou null si aucun PC Sekolify n'est joignable
async function findPC(onProgress) {
    // NB : on ne teste volontairement PAS navigator.onLine. Quand le téléphone est lui-même le point d'accès
    // (partage de connexion) sans données mobiles, Android déclare « aucun réseau actif » alors que le
    // réseau local fonctionne très bien. On tente donc directement la recherche du PC.

    const last = lsGet("sekolify_ip");
    if (last && await probe(last, 1200)) return last;

    const manual = lsGet("sekolify_ip_manual");
    if (manual && manual !== last && await probe(manual, 1200)) return manual;

    const mine = await getLocalIPv4s();
    const myPrefixes = [...new Set(mine.map(ip => ip.split(".").slice(0, 3).join(".")))];
    const prefixes = myPrefixes.length ? myPrefixes : PREFIXES;     // si on connaît notre sous-réseau, inutile de chercher ailleurs

    for (const p of prefixes) {
        const ip = await scanPrefix(p, onProgress);
        if (ip) return ip;
    }
    return null;
}

function connectError(kind, message) { const e = new Error(message || kind); e.kind = kind; return e; }

// Téléphone déjà validé : trouve le PC puis demande le port ACTUEL grâce au jeton
async function locateServer(onProgress) {
    const token = lsGet("sekolify_token");
    const ip = await findPC(onProgress);
    if (!ip) throw connectError("nopc");
    let r;
    try { r = await httpRequest("POST", `http://${ip}:${DISCOVERY_PORT}/resolve`, { token }, 5000); }
    catch (e) { throw connectError("nopc"); }
    if (r.status === 403 && r.data && r.data.code === "PREMIUM_REQUIRED") throw connectError("premium", r.data.error);
    if (r.status === 403) throw connectError("revoked");
    if (r.status !== 200 || !r.data || !r.data.port) throw connectError("nopc");
    lsSet("sekolify_ip", ip);
    return `http://${ip}:${r.data.port}`;
}

function reconnectSilently() {
    if (!reconnectPromise) {
        reconnectPromise = locateServer().then(url => { serverUrl = url; })
            .finally(() => { reconnectPromise = null; });
    }
    return reconnectPromise;
}

const NONET_MSG = "Aucune connexion réseau : activez le Wi-Fi et connectez-vous au même réseau que le PC.";
const NOPC_MSG = "Impossible de joindre le PC. Vérifiez que le logiciel Sekolify est lancé, que vous êtes sur le même Wi-Fi que le PC, et que le pare-feu Windows l'autorise.";


// =====================================================================
//  DÉMARRAGE
// =====================================================================
document.addEventListener("DOMContentLoaded", () => {
    $("input-port").value = "";
    $("input-username").value = lsGet("sekolify_user", "") || "";
    dirty = lsGet("sekolify_dirty", {}) || {};
    loadPresence();
    timetableDay = todayIndex();
    setMainTab(lsGet("sekolify_tab", "home"), true);

    const token = lsGet("sekolify_token");
    const pend = lsGet("sekolify_pending");
    const cached = lsGet("sekolify_data");

    if (token) {
        if (cached) {                                   // affichage immédiat, connexion en arrière-plan
            teacherData = cached; indexGrades(); indexAttendance(); renderMain(); goRoot("view-main");
            autoConnect(true);
        } else {
            goRoot("view-connecting"); autoConnect(false);
        }
    } else if (pend) {
        resumePending(pend);
    } else {
        history.replaceState({ view: "view-login" }, "");
    }

    // les états "appel ouvert / fermé" évoluent avec l'heure : rafraîchissement régulier
    setInterval(tickClock, 30000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) tickClock(); });
});

function tickClock() {
    if (!teacherData || !$("view-main").classList.contains("active")) return;
    if (mainTab === "home") renderHome();
    if (mainTab === "timetable") renderTimetable();
}

// --- Connexion automatique (téléphone déjà validé) ---
function setBanner(text, withRetry, kind, iconName) {
    $("banner-icon").innerHTML = iconName ? icon(iconName, iconName === "loader-circle" ? "ic-spin" : "") : "";
    $("banner-text").textContent = text;
    $("banner-btn").hidden = !withRetry;
    $("offline-banner").className = "banner" + (kind === "info" ? " info" : "");
    $("offline-banner").hidden = !text;
}

function showConnecting(title, text, failed) {
    $("connecting-title").textContent = title;
    $("connecting-text").textContent = text;
    $("connecting-spinner").hidden = !!failed;
    $("connecting-actions").hidden = !failed;
    $("btn-offline").hidden = !(failed && lsGet("sekolify_data"));
    if (!$("view-connecting").classList.contains("active")) goRoot("view-connecting");
}

async function autoConnect(background) {
    if (connectBusy) return;
    connectBusy = true;
    if (background) setBanner("Connexion au PC en cours…", false, "info", "loader-circle");
    else showConnecting("Connexion au PC…", "Recherche du PC sur le Wi-Fi", false);
    try {
        serverUrl = await locateServer(p => {
            if (!background) $("connecting-text").textContent = `Recherche du PC sur le Wi-Fi… (${p}.x)`;
        });
        offlineMode = false;
        setBanner("", false);
        await fetchTeacherData(true);
    } catch (err) {
        handleConnectError(err, background);
    } finally {
        connectBusy = false;
    }
}

function handleConnectError(err, background) {
    if (err.kind === "revoked") { sessionExpired(); return; }
    const msg = err.kind === "nonet" ? NONET_MSG : err.kind === "premium" ? err.message : NOPC_MSG;
    const title = err.kind === "premium" ? "Fonction non disponible" : err.kind === "nonet" ? "Pas de réseau" : "PC introuvable";
    if (window.SekNotif) SekNotif.onOffline();
    if (background && lsGet("sekolify_data")) {
        offlineMode = true;
        renderMain();
        setBanner((err.kind === "nonet" ? "Pas de réseau" : err.kind === "premium" ? "Licence non Premium" : "PC introuvable") + " : mode hors-ligne", true, undefined, "wifi-off");
        showToast(msg, "wifi-off");
    } else {
        showConnecting(title, msg, true);
    }
}

function retryConnect() {
    const background = !!(lsGet("sekolify_data") && inContent());
    autoConnect(background);
}

function continueOffline() {
    teacherData = lsGet("sekolify_data");
    if (!teacherData) return;
    offlineMode = true; indexGrades(); indexAttendance(); renderMain();
    setBanner("Mode hors-ligne : données enregistrées sur le téléphone", true, undefined, "wifi-off");
    goRoot("view-main");
}

// --- Connexion d'un NOUVEAU téléphone ---
function showManualIp() { $("manual-ip-group").hidden = false; $("btn-manual-ip").hidden = true; $("input-ip-manual").focus(); }

async function login(ev) {
    if (ev) ev.preventDefault();
    const port = parseInt($("input-port").value.trim(), 10);
    const username = $("input-username").value.trim();
    const code = $("input-code").value.trim();
    const btn = $("btn-login"), errorMsg = $("login-error");
    errorMsg.textContent = "";

    if (!port || port < 1024 || port > 65535) { errorMsg.textContent = "Entrez le port affiché sur le PC (menu « Application mobile »)."; return; }
    if (!username || !code) { errorMsg.textContent = "Veuillez remplir l'identifiant et le code d'accès."; return; }

    btn.disabled = true; btn.textContent = "Recherche du PC…";
    try {
        // 1) adresse du PC : automatique (ou saisie manuelle en dernier recours)
        const manual = $("input-ip-manual").value.trim();
        let ip;
        if (manual) { lsSet("sekolify_ip_manual", manual); ip = manual; }
        else ip = await findPC(p => { btn.textContent = `Recherche du PC… (${p}.x)`; });
        if (!ip) { errorMsg.textContent = NOPC_MSG; $("btn-manual-ip").hidden = false; return; }
        lsSet("sekolify_ip", ip);

        // 2) demande de connexion
        btn.textContent = "Connexion…";
        serverUrl = `http://${ip}:${port}`;
        let r;
        try {
            r = await httpRequest("POST", `${serverUrl}/api/login`,
                { username, access_code: code, device_id: deviceId(), device_name: deviceName() }, 8000);
        } catch (e) {
            errorMsg.textContent = "Port incorrect ou PC injoignable. Vérifiez le port affiché sur le PC.";
            return;
        }
        const data = r.data || {};
        if (r.status === 200 && data.status === "approved") { await finishLogin(data, username); return; }
        if (r.status === 202 && data.status === "pending") { startPending({ server: serverUrl, request_secret: data.request_secret, username, device_id: deviceId() }); return; }
        errorMsg.textContent = data.error || "Connexion refusée par le PC.";
    } catch (err) {
        errorMsg.textContent = err.kind === "nonet" ? NONET_MSG : (err.message || "Erreur de connexion.");
    } finally {
        btn.disabled = false; btn.textContent = "Se connecter";
    }
}

async function finishLogin(data, username) {
    if (lsGet("sekolify_user") && lsGet("sekolify_user") !== username) { dirty = {}; presenceStore = {}; lsDel("sekolify_dirty", "sekolify_data", PRESENCE_KEY); }
    lsSet("sekolify_token", data.token);
    lsSet("sekolify_user", username);
    lsSet("sekolify_teacher_name", data.teacher_name || username);
    lsSet("sekolify_school_name", data.school_name || "");
    lsDel("sekolify_pending");
    clearTimeout(pendingTimer);
    $("input-code").value = "";
    await fetchTeacherData(false);
}

// --- Attente de validation par l'administration ---
function startPending(p) {
    lsSet("sekolify_pending", p);
    pendingFails = 0;
    $("pending-info").innerHTML = `<strong>${esc(p.username)}</strong> · ${esc(deviceName())}`;
    $("pending-status").textContent = "En attente de validation…";
    goRoot("view-pending");
    pollPending();
}

function resumePending(p) {
    serverUrl = p.server;
    startPending(p);
}

async function pollPending() {
    clearTimeout(pendingTimer);
    const p = lsGet("sekolify_pending");
    if (!p) return;
    try {
        const r = await httpRequest("POST", `${p.server}/api/login/status`, { device_id: p.device_id, request_secret: p.request_secret }, 6000);
        pendingFails = 0;
        const d = r.data || {};
        if (r.status === 200 && d.status === "approved") { serverUrl = p.server; await finishLogin(d, p.username); return; }
        if (r.status === 200 && d.status === "rejected") { endPending("Votre demande a été refusée par l'administration."); return; }
        if (r.status === 404 || r.status === 403) { endPending(d.error || "Demande introuvable : recommencez."); return; }
        $("pending-status").textContent = "En attente de validation…";
    } catch (e) {
        pendingFails++;
        $("pending-status").textContent = "Connexion au PC perdue… nouvelle tentative";
        if (pendingFails >= 8) { endPending("Le PC ne répond plus (il a peut-être été relancé : le port a changé). Refaites la demande avec le nouveau port."); return; }
    }
    pendingTimer = setTimeout(pollPending, 3000);
}

function endPending(message) {
    clearTimeout(pendingTimer);
    lsDel("sekolify_pending");
    $("login-error").textContent = message;
    goRoot("view-login");
}
function cancelPending() { endPending(""); }

// --- DONNÉES ---
async function fetchTeacherData(silent) {
    try {
        const response = await api("GET", "/api/mes-donnees");
        if (response.status === 401) { sessionExpired(); return; }
        if (response.status === 403) {
            const msg = (response.data && response.data.error) || "Accès refusé.";
            if (lsGet("sekolify_data")) { offlineMode = true; setBanner(msg, false, undefined, "lock"); showToast(msg, "lock"); renderMain(); if (!inContent()) goRoot("view-main"); }
            else showConnecting("Fonction non disponible", msg, true);
            return;
        }
        if (response.status !== 200 || !response.data) throw new Error("Erreur serveur");

        teacherData = response.data;
        lsSet("sekolify_data", teacherData);
        offlineMode = false;
        setBanner("", false);
        indexGrades();
        indexAttendance();
        relinkNav();
        renderMain();
        if (!inContent()) goRoot("view-main");
        else if ($("view-notes").classList.contains("active")) renderNotesView();
        else if ($("view-periods").classList.contains("active")) renderPeriods();
        if (window.SekNotif) SekNotif.onConnected(teacherData, pendingTotal());   // notifications
        if (!silent) showToast("Connexion réussie", "check");
    } catch (err) {
        const cached = teacherData || lsGet("sekolify_data");
        if (cached) {
            teacherData = cached; offlineMode = true; indexGrades(); indexAttendance(); renderMain();
            if (window.SekNotif) SekNotif.onOffline();
            setBanner("PC introuvable : mode hors-ligne", true, undefined, "wifi-off");
            if (!inContent()) goRoot("view-main");
            showToast(err.kind === "nonet" ? NONET_MSG : "PC injoignable : mode hors-ligne", "wifi-off");
        } else {
            handleConnectError(err.kind ? err : connectError("nopc"), false);
        }
    }
}

// après une actualisation, rattache la classe/matière ouvertes aux nouveaux objets
function relinkNav() {
    if (!teacherData || !nav.cls) return;
    const cls = teacherData.classes.find(c => c.id === nav.cls.id);
    if (!cls) { nav = { cls: null, period: null, cs: null }; return; }
    nav.cls = cls;
    nav.cs = (nav.cs && cls.subjects.find(s => s.class_subject_id === nav.cs.class_subject_id)) || cls.subjects[0] || null;
}

async function refreshData() {
    if (pendingTotal() > 0) showToast("Des données attendent d'être envoyées au PC.", "info");
    else showToast("Actualisation…", "loader-circle");
    await autoConnect(true);
    if (!offlineMode) showToast("Données à jour", "check");
}

function sessionExpired() {
    lsDel("sekolify_token");
    clearTimeout(pendingTimer);
    $("login-error").textContent = "Accès retiré ou expiré. Refaites une demande de connexion (vos données non envoyées sont conservées).";
    goRoot("view-login");
}

function logout() {
    const n = pendingTotal();
    if (n > 0 && !confirm(`${n} élément(s) (notes ou appels) n'ont pas été envoyés au PC. Se déconnecter les supprimera. Continuer ?`)) return;
    lsDel("sekolify_token", "sekolify_data", "sekolify_dirty", PRESENCE_KEY, "sekolify_teacher_name", "sekolify_school_name", "sekolify_pending");
    dirty = {}; baseGrades = {}; presenceStore = {}; serverAtt = {}; appel = null;
    teacherData = null; nav = { cls: null, period: null, cs: null };
    if (window.SekNotif) SekNotif.onLogout();
    setBanner("", false);
    $("login-error").textContent = "";
    goRoot("view-login");
}

function indexGrades() {
    baseGrades = {};
    ((teacherData && teacherData.grades) || []).forEach(g => {
        baseGrades[gkey(g.class_subject_id, g.student_id, g.period, g.type, g.index)] = g.value;
    });
}

// --- ACCÈS AUX NOTES ---
function getValue(key) {
    if (key in dirty) return dirty[key].value;
    return key in baseGrades ? baseGrades[key] : null;
}

function setValue(entry, value) {
    const key = gkey(entry.class_subject_id, entry.student_id, entry.period, entry.type, entry.index);
    const base = key in baseGrades ? baseGrades[key] : null;
    if (value === base) delete dirty[key];
    else dirty[key] = Object.assign({}, entry, { value });
    lsSet("sekolify_dirty", dirty);
}

// --- PRÉSENCE : STOCKAGE LOCAL ---
const pkey = (classId, date, hour) => `${classId}|${date}|${hour}`;

function loadPresence() {
    presenceStore = lsGet(PRESENCE_KEY, {}) || {};
    const limit = new Date(); limit.setDate(limit.getDate() - PRESENCE_KEEP_DAYS);
    const lim = dateStr(limit);
    Object.keys(presenceStore).forEach(k => {          // on ne garde que les appels récents déjà réglés
        const r = presenceStore[k];
        if (r.date < lim && (r.sent || r.error)) delete presenceStore[k];
    });
    savePresence();
}
function savePresence() { lsSet(PRESENCE_KEY, presenceStore); }

function indexAttendance() {
    serverAtt = {};
    ((teacherData && teacherData.attendance) || []).forEach(g => { serverAtt[pkey(g.class_id, g.date, g.hour)] = g; });
}

function presenceSupported() { return !!(teacherData && teacherData.server_now); }
function pendingNotes() { return Object.keys(dirty).length; }
function pendingPresence() { return Object.values(presenceStore).filter(r => !r.sent && !r.error).length; }
function pendingTotal() { return pendingNotes() + pendingPresence(); }
function pendingText() {
    const n = pendingNotes(), p = pendingPresence(), parts = [];
    if (n) parts.push(`${n} note(s)`);
    if (p) parts.push(`${p} appel(s)`);
    return parts.length ? parts.join(" et ") + " à envoyer" : "";
}

// --- PRÉSENCE : ÉTAT D'UN CRÉNEAU ---
function slotsOfDay(dayIdx, dateS) {
    return ((teacherData && teacherData.timetable) || []).filter(s => s.day === dayIdx)
        .sort((a, b) => a.hour - b.hour)
        .map(s => makeSlot(s, s.hour, dateS));
}
function makeSlot(s, hour, dateS) {
    const slot = { class_id: s.class_id, class_name: s.class_name, subject_id: s.subject_id, subject_name: s.subject_name,
                   hour, date: dateS, key: pkey(s.class_id, dateS, hour) };
    slotIndex[slot.key] = slot;
    return slot;
}

// État de l'appel d'un créneau horaire (aujourd'hui) : { code, label, tone, editable, exists, detail }
function appelState(slot, now) {
    const rec = presenceStore[slot.key];
    const srv = serverAtt[slot.key];
    const today = slot.date === dateStr(now);
    if (rec && rec.error) return { code: "refused", label: "Refusé", tone: "bad", editable: false, exists: true, detail: rec.error };
    if (rec) return rec.sent
        ? { code: "sent", label: "Envoyé", tone: "ok", editable: today, exists: true }
        : { code: "pending", label: "À envoyer", tone: "warn", editable: today, exists: true };
    if (srv) return srv.by_me
        ? { code: "sent", label: "Envoyé", tone: "ok", editable: today, exists: true }
        : { code: "pc", label: "Fait sur le PC", tone: "muted", editable: false, exists: true };
    const w = windowState(slot.hour, now);
    if (w === "open") return { code: "open", label: "Appel ouvert", tone: "accent", editable: true, exists: false };
    if (w === "upcoming") return { code: "upcoming", label: "Ouvre à " + fmtMin(slot.hour * 60 - earlyMin()), tone: "muted", editable: false, exists: false };
    return { code: "missed", label: "Non fait", tone: "muted", editable: false, exists: false };
}

function tapAppel(key) {
    const slot = slotIndex[key];
    if (!slot) return;
    const st = appelState(slot, new Date());
    if (st.code === "upcoming") { showToast(`L'appel ouvre à ${fmtMin(slot.hour * 60 - earlyMin())}, ${earlyMin()} min avant le cours.`, "clock"); return; }
    if (st.code === "missed") { showToast("L'heure de l'appel est passée pour ce créneau.", "clock"); return; }
    openAppel(slot);
}

// --- ONGLETS PRINCIPAUX : ACCUEIL / CLASSES / EMPLOI DU TEMPS ---
function setMainTab(tab, silent) {
    if (!["home", "classes", "timetable"].includes(tab)) tab = "home";
    mainTab = tab;
    ["home", "classes", "timetable"].forEach(t => {
        $("nav-" + t).classList.toggle("active", t === tab);
        $("main-" + t).hidden = t !== tab;
    });
    lsSet("sekolify_tab", tab);
    $("view-main").scrollTop = 0;
    if (!silent) renderMain();
}

function renderMain() {
    $("main-title").textContent = lsGet("sekolify_teacher_name", "") || "Sekolify Prof";
    $("main-sub").textContent = lsGet("sekolify_school_name") || cfg().school_name || "";
    slotIndex = {};
    renderHome();
    renderClasses();
    renderTimetable();
    refreshPendingUI();
}

// --- ACCUEIL ---
function renderHome() {
    const now = new Date();
    $("home-date").textContent = `${DAYS_FULL[weekdayIndex(now)]} ${now.getDate()} ${MONTHS[now.getMonth()]}`;
    const box = $("home-appels");

    if (!teacherData) { box.innerHTML = ""; return; }
    if (!presenceSupported()) {
        box.innerHTML = `<p class="empty">${icon("info")}La présence n'est pas encore disponible : mettez à jour Sekolify sur le PC de l'école, puis actualisez.</p>`;
        return;
    }
    const slots = todaySlots(now);
    if (!slots.length) {
        const any = ((teacherData.timetable) || []).length;
        box.innerHTML = `<p class="empty">${any ? "Aucun cours aujourd'hui." : "Votre emploi du temps n'est pas encore renseigné par l'administration."}</p>`;
        return;
    }
    box.innerHTML = slots.map(s => {
        const st = appelState(s, now);
        const ico = st.code === "sent" ? "check" : st.code === "pending" ? "cloud-upload" : st.code === "refused" ? "x" : st.code === "pc" ? "lock" : "clock";
        return `<button class="appel-card ${st.code}" data-key="${esc(s.key)}" onclick="tapAppel(this.dataset.key)">
            <div class="appel-time">${hh(s.hour)}<small>${hh(s.hour + 1)}</small></div>
            <div class="appel-main">
                <div class="appel-subject">${esc(s.subject_name)}</div>
                <div class="appel-class">${esc(s.class_name)}</div>
            </div>
            <span class="pill tone-${st.tone}">${st.code === "open" ? icon("clipboard-check") : icon(ico)}${esc(st.label)}</span>
        </button>`;
    }).join("");
}
function todaySlots(now) { return slotsOfDay(weekdayIndex(now), dateStr(now)); }

// --- EMPLOI DU TEMPS ---
// fusionne les heures consécutives d'une même classe/matière : 8h+9h => 08:00 - 10:00
function mergedSlots(day) {
    const slots = ((teacherData && teacherData.timetable) || []).filter(s => s.day === day).sort((a, b) => a.hour - b.hour);
    const out = [];
    slots.forEach(s => {
        const last = out[out.length - 1];
        if (last && last.class_name === s.class_name && last.subject_name === s.subject_name && last.end === s.hour) last.end = s.hour + 1;
        else out.push({ class_id: s.class_id, class_name: s.class_name, subject_id: s.subject_id, subject_name: s.subject_name, start: s.hour, end: s.hour + 1 });
    });
    return out;
}

function hourChips(block, now) {
    const dateS = dateStr(now);
    const chips = [];
    for (let h = block.start; h < block.end; h++) {
        const slot = makeSlot(block, h, dateS);
        const st = appelState(slot, now);
        chips.push(`<button class="hour-chip tone-${st.tone}" data-key="${esc(slot.key)}" onclick="tapAppel(this.dataset.key)">${icon("clipboard-check")}<span>${hh(h)}</span><small>${esc(st.label)}</small></button>`);
    }
    return `<div class="hour-chips">${chips.join("")}</div>`;
}

function renderTimetable() {
    const all = (teacherData && teacherData.timetable) || [];
    const pills = $("day-pills");
    pills.innerHTML = "";
    const now = new Date();
    const today = weekdayIndex(now);
    DAY_NAMES.forEach((name, i) => {
        const hours = all.filter(s => s.day === i).length;
        const b = document.createElement("button");
        b.className = "day-pill" + (i === timetableDay ? " active" : "") + (i === today ? " today" : "");
        b.innerHTML = `<b>${name.slice(0, 3)}</b><small>${hours ? hours + " h" : "-"}</small>`;
        b.onclick = () => { timetableDay = i; renderTimetable(); };
        pills.appendChild(b);
    });

    const list = $("slots-list");
    if (!all.length) {
        list.innerHTML = "<p class='empty'>Aucun créneau pour le moment.<br>L'administration n'a pas encore renseigné votre emploi du temps.</p>";
        return;
    }
    const slots = mergedSlots(timetableDay);
    if (!slots.length) { list.innerHTML = `<p class='empty'>${icon("smile")}Aucun cours ce ${DAY_NAMES[timetableDay].toLowerCase()}</p>`; return; }

    const nowH = now.getHours() + now.getMinutes() / 60;
    const total = slots.reduce((a, s) => a + (s.end - s.start), 0);
    const withChips = timetableDay === today && presenceSupported();
    list.innerHTML = `<div class="day-summary">${DAY_NAMES[timetableDay]} · ${total} h de cours · ${slots.length} séance(s)</div>` +
        slots.map(s => {
            const isNow = timetableDay === today && nowH >= s.start && nowH < s.end;
            return `<div class="slot-card${isNow ? " now" : ""}">
                <div class="slot-top">
                    <div class="slot-time">${hh(s.start)}<small>${hh(s.end)}</small></div>
                    <div class="slot-main">
                        ${isNow ? '<span class="slot-now">EN COURS</span>' : ""}
                        <div class="slot-subject">${esc(s.subject_name)}</div>
                        <span class="slot-class">${esc(s.class_name)}</span>
                    </div>
                </div>
                ${withChips ? hourChips(s, now) : ""}
            </div>`;
        }).join("");
}

// --- CLASSES ---
function renderClasses() {
    const container = $("classes-list");
    if (!teacherData || !teacherData.classes || !teacherData.classes.length) {
        container.innerHTML = "<p class='empty'>Aucune classe assignée.<br>Demandez à l'administration d'associer vos matières.</p>";
        return;
    }
    container.innerHTML = "";
    teacherData.classes.forEach(cls => {
        const pend = classPending(cls);
        const div = document.createElement("button");
        div.className = "list-item";
        div.onclick = () => openClass(cls);
        const subjects = cls.subjects.length ? cls.subjects.map(s => s.name).join(", ") : "aucune matière notée";
        div.innerHTML = `
            <div class="badge-circle">${esc(cls.name.slice(0, 3))}</div>
            <div class="list-main">
                <div class="list-item-title">${esc(cls.name)}</div>
                <div class="list-item-sub">${cls.students.length} élève(s) · ${esc(subjects)}</div>
            </div>
            ${pend ? `<span class="pending-pill">${pend}</span>` : ""}
            <span class="chev">${icon("chevron-right")}</span>`;
        container.appendChild(div);
    });
}

function classPending(cls) {
    const ids = new Set(cls.subjects.map(s => String(s.class_subject_id)));
    return Object.values(dirty).filter(d => ids.has(String(d.class_subject_id))).length;
}

// --- VUE 3 : PÉRIODES ---
function openClass(cls) {
    nav.cls = cls;
    nav.cs = cls.subjects[0] || null;
    renderPeriods();
    go("view-periods");
}

function periodProgress(cls, period) {
    const idx = dsIndexes();
    let filled = 0, total = 0;
    cls.subjects.forEach(sub => cls.students.forEach(st => {
        idx.forEach(i => { total++; if (getValue(gkey(sub.class_subject_id, st.id, period, "DS", i)) !== null) filled++; });
        total++; if (getValue(gkey(sub.class_subject_id, st.id, period, "EXAM", 0)) !== null) filled++;
    }));
    return total ? Math.round(filled * 100 / total) : 0;
}

function renderPeriods() {
    const cls = nav.cls;
    if (!cls) return;
    $("periods-title").textContent = cls.name;
    $("periods-sub").textContent = "Choisissez la période";
    const c = cfg();
    const container = $("periods-list");
    container.innerHTML = "";
    for (let p = 1; p <= c.period_count; p++) {
        const pct = periodProgress(cls, p);
        const div = document.createElement("button");
        div.className = "list-item";
        div.onclick = () => openPeriod(p);
        div.innerHTML = `
            <div class="badge-circle">${p}</div>
            <div class="list-main">
                <div class="list-item-title">${periodLabel(p)}</div>
                <div class="list-item-sub">${c.ds_per_period} DS + examen · ${pct}% saisi</div>
                <div class="mini-progress"><div style="width:${pct}%"></div></div>
            </div>
            <span class="chev">${icon("chevron-right")}</span>`;
        container.appendChild(div);
    }
}

// --- VUE 4 : SAISIE ---
function openPeriod(p) {
    nav.period = p;
    nav.cs = nav.cs || nav.cls.subjects[0];
    $("search-student").value = "";
    renderNotesView();
    go("view-notes");
}

function renderNotesView() {
    if (!nav.cls || !nav.period) return;
    $("notes-title").textContent = nav.cls.name;
    $("notes-sub").textContent = periodLabel(nav.period);

    const chips = $("subject-chips");
    chips.innerHTML = "";
    chips.hidden = nav.cls.subjects.length === 0;
    nav.cls.subjects.forEach(sub => {
        const b = document.createElement("button");
        b.className = "chip" + (nav.cs && nav.cs.class_subject_id === sub.class_subject_id ? " active" : "");
        b.textContent = sub.name;
        b.onclick = () => { nav.cs = sub; renderNotesView(); };
        chips.appendChild(b);
    });
    renderStudents();
}

function noteEntry(studentId, type, index) {
    return { class_subject_id: nav.cs.class_subject_id, student_id: studentId, period: nav.period, type, index };
}

function renderStudents() {
    const container = $("students-list");
    if (!nav.cs) { container.innerHTML = "<p class='empty'>Aucune matière assignée.</p>"; return; }
    const q = $("search-student").value.trim().toLowerCase();
    const idx = dsIndexes();
    const students = nav.cls.students.filter(s => !q || s.name.toLowerCase().includes(q) || String(s.matricule || "").toLowerCase().includes(q));

    container.innerHTML = "";
    if (!students.length) { container.innerHTML = "<p class='empty'>Aucun élève trouvé.</p>"; updateStatus(); return; }

    students.forEach((st, n) => {
        const row = document.createElement("div");
        row.className = "student-row";
        row.dataset.student = st.id;

        const cells = idx.map(i => cellHtml(st.id, "DS", i, `DS${i}`, false)).join("") + cellHtml(st.id, "EXAM", 0, "EXAMEN", true);
        row.innerHTML = `
            <div class="student-head">
                <div class="student-num">${n + 1}</div>
                <div class="student-info">
                    <div class="student-name">${esc(st.name)}</div>
                    <div class="student-mat">${esc(st.matricule || "")}</div>
                </div>
                <div class="avg" data-avg="${st.id}">–</div>
            </div>
            <div class="note-grid">${cells}</div>`;
        container.appendChild(row);
        updateAvg(st.id);
    });

    container.querySelectorAll(".note-input").forEach(inp => {
        inp.addEventListener("input", onNoteInput);
        inp.addEventListener("focus", () => inp.select());
        inp.addEventListener("keydown", onNoteKey);
    });
    updateStatus();
}

function cellHtml(studentId, type, index, label, isExam) {
    const key = gkey(nav.cs.class_subject_id, studentId, nav.period, type, index);
    const v = getValue(key);
    const cls = "note-input" + (key in dirty ? " dirty" : "");
    return `<div class="note-cell${isExam ? " exam" : ""}">
        <label>${label}</label>
        <input type="text" inputmode="decimal" autocomplete="off" class="${cls}"
               data-st="${studentId}" data-type="${type}" data-index="${index}"
               value="${v === null ? "" : String(v).replace(".", ",")}" placeholder="–" enterkeyhint="next">
    </div>`;
}

function onNoteInput(e) {
    const inp = e.target;
    let raw = inp.value.replace(/[^0-9.,]/g, "");
    if (raw !== inp.value) inp.value = raw;
    const st = Number(inp.dataset.st), type = inp.dataset.type, index = Number(inp.dataset.index);
    const entry = noteEntry(st, type, index);

    if (raw === "") {
        inp.classList.remove("invalid");
        setValue(entry, null);
    } else {
        const num = parseFloat(raw.replace(",", "."));
        const max = cfg().max_score;
        if (isNaN(num) || num < 0 || num > max) { inp.classList.add("invalid"); return; }
        inp.classList.remove("invalid");
        setValue(entry, num);
    }
    const key = gkey(entry.class_subject_id, st, entry.period, type, index);
    inp.classList.toggle("dirty", key in dirty);
    updateAvg(st);
    updateStatus();
}

function onNoteKey(e) {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const all = Array.from(document.querySelectorAll("#students-list .note-input"));
    const next = all[all.indexOf(e.target) + 1];
    if (next) next.focus(); else e.target.blur();
}

function updateAvg(studentId) {
    const el = document.querySelector(`[data-avg="${studentId}"]`);
    if (!el || !nav.cs) return;
    const c = cfg();
    const ds = dsIndexes().map(i => getValue(gkey(nav.cs.class_subject_id, studentId, nav.period, "DS", i))).filter(v => v !== null);
    const exam = getValue(gkey(nav.cs.class_subject_id, studentId, nav.period, "EXAM", 0));
    if (!ds.length && exam === null) { el.textContent = "–"; el.className = "avg"; return; }
    const avgDs = ds.length ? ds.reduce((a, b) => a + b, 0) / ds.length : 0;
    const w = c.weight_ds + c.weight_exam;
    const avg = w > 0 ? (avgDs * c.weight_ds + (exam || 0) * c.weight_exam) / w : 0;
    el.textContent = avg.toFixed(2).replace(".", ",");
    el.className = "avg " + (avg >= c.max_score / 2 ? "good" : "low");
}

function updateStatus() {
    // progression de la matière / période affichée
    if (nav.cs && nav.cls) {
        const idx = dsIndexes();
        let filled = 0, total = 0;
        nav.cls.students.forEach(st => {
            idx.forEach(i => { total++; if (getValue(gkey(nav.cs.class_subject_id, st.id, nav.period, "DS", i)) !== null) filled++; });
            total++; if (getValue(gkey(nav.cs.class_subject_id, st.id, nav.period, "EXAM", 0)) !== null) filled++;
        });
        const pct = total ? Math.round(filled * 100 / total) : 0;
        $("progress-bar").style.width = pct + "%";
        $("progress-text").textContent = `${nav.cs.name} · ${filled}/${total} notes saisies (${pct}%)`;
    }
    refreshPendingUI();
}


// =====================================================================
//  PRÉSENCE : ÉCRAN D'APPEL
// =====================================================================
function openAppel(slot) {
    const now = new Date();
    const st = appelState(slot, now);
    const cls = ((teacherData && teacherData.classes) || []).find(c => c.id === slot.class_id);
    if (!cls) { showToast("Classe introuvable : actualisez les données.", "triangle-alert"); return; }

    const rec = presenceStore[slot.key];
    const srv = serverAtt[slot.key];
    const entries = {};
    cls.students.forEach(s => { entries[s.id] = "PRESENT"; });      // par défaut : tous présents, le prof marque les absents
    if (rec) Object.keys(rec.entries).forEach(sid => { entries[sid] = rec.entries[sid]; });
    else if (srv) srv.records.forEach(r => { entries[r[0]] = r[1]; });

    appel = { slot, cls, entries, readOnly: !st.editable, dirty: false, state: st };
    renderAppel();
    go("view-presence");
}

function renderAppel() {
    if (!appel) return;
    const { slot, cls, readOnly, state } = appel;
    $("presence-title").textContent = cls.name;
    $("presence-sub").textContent = `${slot.subject_name} · ${hh(slot.hour)} - ${hh(slot.hour + 1)}`;

    const info = $("presence-info");
    info.hidden = false;
    info.className = "info-strip";
    if (state.code === "pc") {
        info.className = "info-strip lock";
        info.innerHTML = icon("lock") + "<span>Appel déjà enregistré sur le PC de l'école : lecture seule.</span>";
    } else if (state.code === "refused") {
        info.className = "info-strip bad";
        info.innerHTML = icon("triangle-alert") + `<span>Refusé par le PC : ${esc(state.detail || "")}</span><button class="btn-link" onclick="discardRefused()">Effacer et refaire</button>`;
    } else if (readOnly) {
        info.className = "info-strip lock";
        info.innerHTML = icon("lock") + "<span>Correction impossible : seulement le jour même.</span>";
    } else if (state.exists) {
        info.innerHTML = icon("info") + "<span>Appel déjà fait : vous pouvez le corriger aujourd'hui.</span>";
    } else {
        info.innerHTML = icon("clock") + `<span>Appel ouvert jusqu'à ${hh(slot.hour + 1)}. Tous les élèves sont présents par défaut.</span>`;
    }

    $("p-tools").hidden = readOnly;
    const list = $("presence-list");
    list.innerHTML = cls.students.map((st, n) => {
        const cur = appel.entries[st.id];
        const btn = (code, cssName, label) => `<button class="seg-btn s-${cssName}${cur === code ? " on" : ""}" data-s="${code}">${label}</button>`;
        return `<div class="p-row${readOnly ? " readonly" : ""}" data-sid="${st.id}">
            <div class="student-head" style="margin:0">
                <div class="student-num">${n + 1}</div>
                <div class="student-info">
                    <div class="student-name">${esc(st.name)} ${cur === "EXCUSE" ? '<span class="excuse-tag">Excusé</span>' : ""}</div>
                    <div class="student-mat">${esc(st.matricule || "")}</div>
                </div>
            </div>
            <div class="seg">${btn("PRESENT", "present", "Présent")}${btn("ABSENT", "absent", "Absent")}${btn("RETARD", "retard", "Retard")}</div>
        </div>`;
    }).join("") || "<p class='empty'>Aucun élève dans cette classe.</p>";

    list.onclick = e => {
        const b = e.target.closest(".seg-btn");
        if (!b || !appel || appel.readOnly) return;
        const row = b.closest(".p-row");
        appel.entries[row.dataset.sid] = b.dataset.s;
        appel.dirty = true;
        row.querySelectorAll(".seg-btn").forEach(x => x.classList.toggle("on", x === b));
        const tag = row.querySelector(".excuse-tag"); if (tag) tag.remove();
        updateAppelSummary();
        updateAppelBar();
    };
    updateAppelSummary();
    updateAppelBar();
}

function updateAppelSummary() {
    if (!appel) return;
    const c = { PRESENT: 0, ABSENT: 0, RETARD: 0, EXCUSE: 0 };
    appel.cls.students.forEach(s => { const v = appel.entries[s.id]; if (v in c) c[v]++; });
    $("p-summary").innerHTML =
        `<div class="p-count ok"><b>${c.PRESENT}</b><span>Présents</span></div>` +
        `<div class="p-count bad"><b>${c.ABSENT}</b><span>Absents</span></div>` +
        `<div class="p-count warn"><b>${c.RETARD}</b><span>Retards</span></div>` +
        (c.EXCUSE ? `<div class="p-count"><b>${c.EXCUSE}</b><span>Excusés</span></div>` : "");
}

function markAll(status) {
    if (!appel || appel.readOnly) return;
    appel.cls.students.forEach(s => { appel.entries[s.id] = status; });
    appel.dirty = true;
    renderAppel();
}

function leaveAppel() {
    if (appel && appel.dirty && !confirm("Quitter sans enregistrer l'appel ?")) return;
    if (appel) appel.dirty = false;
    history.back();
}

function discardRefused() {
    if (!appel) return;
    delete presenceStore[appel.slot.key];
    savePresence();
    appel.dirty = false;
    history.back();
    renderMain();
    showToast("Appel effacé. Vous pouvez le refaire si l'heure le permet.", "info");
}

function saveAppel() {
    if (!appel || appel.readOnly) return;
    const now = new Date();
    const slot = appel.slot;
    const st = appelState(slot, now);
    if (!st.editable) {
        showToast("Hors de l'heure de l'appel : enregistrement impossible.", "triangle-alert");
        return;
    }
    const old = presenceStore[slot.key];
    presenceStore[slot.key] = {
        class_id: slot.class_id, subject_id: slot.subject_id, class_name: slot.class_name, subject_name: slot.subject_name,
        date: slot.date, hour: slot.hour,
        created_at: old ? old.created_at : stampStr(now), updated_at: stampStr(now),
        entries: Object.assign({}, appel.entries), sent: false
    };
    savePresence();
    appel.dirty = false;
    appel.state = appelState(slot, now);
    showToast("Appel enregistré. Pensez à l'envoyer au PC.", "check");
    refreshPendingUI();
    renderHome();
}

function presenceBarAction() {
    const mode = $("presence-bar-btn").dataset.mode;
    if (mode === "save") saveAppel(); else syncAll();
}

function updateAppelBar() {
    const bar = $("presence-bar");
    if (!appel || appel.readOnly) { bar.hidden = true; return; }
    bar.hidden = false;
    const txt = $("presence-bar-text"), btn = $("presence-bar-btn");
    if (appel.dirty || !appel.state.exists) {
        txt.className = appel.dirty ? "pending" : "";
        txt.textContent = appel.dirty ? "Modifications non enregistrées" : "Appel non enregistré";
        btn.textContent = "Enregistrer l'appel"; btn.dataset.mode = "save"; btn.disabled = false;
    } else {
        const total = pendingTotal();
        txt.className = total ? "pending" : "";
        if (total) txt.textContent = pendingText(); else txt.innerHTML = icon("check") + "Tout est synchronisé";
        btn.textContent = syncBusy ? "Envoi…" : "Envoyer au PC"; btn.dataset.mode = "sync"; btn.disabled = syncBusy || total === 0;
    }
}

// =====================================================================
//  SYNCHRONISATION AVEC LE PC (notes + présence)
// =====================================================================
function refreshPendingUI() {
    const total = pendingTotal();
    const label = syncBusy ? "Envoi…" : "Envoyer au PC";
    const t = $("sync-text");
    if (total) { t.textContent = pendingText(); t.className = "pending"; }
    else { t.innerHTML = icon("check") + "Tout est synchronisé"; t.className = ""; }
    $("btn-sync").textContent = label; $("btn-sync").disabled = syncBusy || total === 0;

    const ht = $("home-sync-text");
    if (total) { ht.textContent = pendingText(); ht.className = "sync-card-text pending"; }
    else { ht.innerHTML = icon("check") + "Tout est synchronisé"; ht.className = "sync-card-text"; }
    $("home-sync-btn").textContent = label; $("home-sync-btn").disabled = syncBusy || total === 0;

    updateAppelBar();
    if (window.SekNotif) SekNotif.onPending(total);
}

async function syncAll() {
    if (syncBusy) return;
    if (pendingTotal() === 0) { showToast("Rien à envoyer."); return; }
    syncBusy = true; refreshPendingUI();
    const msgs = []; let failed = false;
    try {
        if (pendingNotes() > 0) {
            const r = await syncNotesRequest();
            if (r.fatal) return;
            msgs.push(r.msg); if (!r.ok) failed = true;
        }
        if (pendingPresence() > 0) {
            const r = await syncPresenceRequest();
            if (r.fatal) return;
            msgs.push(r.msg); if (!r.ok) failed = true;
        }
        showToast(msgs.filter(Boolean).join(" "), failed ? "triangle-alert" : "check");
    } catch (err) {
        showToast("PC injoignable : vos données restent enregistrées sur le téléphone.", "wifi-off");
    } finally {
        syncBusy = false;
        refreshPendingUI();
        renderHome();
        if ($("view-main").classList.contains("active")) renderTimetable();
    }
}

async function syncNotesRequest() {
    const entries = Object.entries(dirty);
    const response = await api("POST", "/api/sync-notes", { notes: entries.map(([, e]) => e) }, 20000);
    if (response.status === 401) { sessionExpired(); return { fatal: true }; }
    if (response.status === 403) return { ok: false, msg: (response.data && response.data.error) || "Accès refusé." };
    const data = response.data || {};
    if (response.status !== 200) throw new Error(data.error || "Erreur serveur");
    if (data.errors && data.errors.length) return { ok: false, msg: `${data.synced} note(s) envoyée(s), ${data.errors.length} erreur(s).` };

    entries.forEach(([key, e]) => { baseGrades[key] = e.value; delete dirty[key]; });
    if (teacherData) {                         // garde le cache local cohérent avec le serveur
        teacherData.grades = Object.entries(baseGrades).filter(([, v]) => v !== null).map(([k, v]) => {
            const [cs, st, period, type, index] = k.split("|");
            return { class_subject_id: +cs, student_id: +st, period: +period, type, index: +index, value: v };
        });
        lsSet("sekolify_data", teacherData);
    }
    lsSet("sekolify_dirty", dirty);
    document.querySelectorAll(".note-input.dirty").forEach(i => i.classList.remove("dirty"));
    return { ok: true, msg: `${data.synced} note(s) envoyée(s).` };
}

async function syncPresenceRequest() {
    const recs = Object.values(presenceStore).filter(r => !r.sent && !r.error);
    const body = { presences: recs.map(r => ({
        class_id: r.class_id, date: r.date, hour: r.hour, created_at: r.created_at, updated_at: r.updated_at,
        entries: Object.entries(r.entries).map(([sid, status]) => ({ student_id: Number(sid), status }))
    })) };
    const response = await api("POST", "/api/sync-presence", body, 20000);
    if (response.status === 401) { sessionExpired(); return { fatal: true }; }
    if (response.status === 403) return { ok: false, msg: (response.data && response.data.error) || "Accès refusé." };
    if (response.status === 404) return { ok: false, msg: "Mettez à jour Sekolify sur le PC : l'envoi des appels n'y est pas pris en charge." };
    const data = response.data || {};
    if (response.status !== 200) throw new Error(data.error || "Erreur serveur");

    let ok = 0, refused = 0;
    (data.results || []).forEach(res => {
        const rec = presenceStore[pkey(res.class_id, res.date, res.hour)];
        if (!rec) return;
        if (res.status === "ok") { rec.sent = true; delete rec.error; mirrorAttendance(rec); ok++; }
        else { rec.error = res.message || "Appel refusé."; refused++; }
    });
    savePresence();
    if (teacherData) lsSet("sekolify_data", teacherData);
    const parts = [];
    if (ok) parts.push(`${ok} appel(s) envoyé(s)`);
    if (refused) parts.push(`${refused} refusé(s) par le PC`);
    return { ok: refused === 0, msg: (parts.join(", ") || "Aucun appel traité") + "." };
}

// garde le cache local cohérent : l'appel envoyé devient un appel connu du serveur
function mirrorAttendance(rec) {
    if (!teacherData) return;
    const key = pkey(rec.class_id, rec.date, rec.hour);
    const group = { class_id: rec.class_id, date: rec.date, hour: rec.hour, by_me: true,
                    records: Object.entries(rec.entries).map(([sid, status]) => [Number(sid), status, ""]) };
    teacherData.attendance = (teacherData.attendance || []).filter(g => pkey(g.class_id, g.date, g.hour) !== key).concat([group]);
    serverAtt[key] = group;
}
