// =====================================================================
//  NOTIFICATIONS — rappels de cours + alerte de synchronisation
//  (module séparé : ne touche pas à la logique de app.js, qui l'appelle via SekNotif.*)
//   • Rappel 10 min avant chaque bloc de cours, planifié sur l'alarme du téléphone
//     (sonne même app fermée), recalculé à chaque synchronisation de l'emploi du temps
//   • « Connecté au serveur : synchronisez vos notes » quand des notes attendent
//     (app ouverte : ici ; app fermée : SyncWatcher.java, toutes les ~15 min)
// =====================================================================
(function () {
    "use strict";

    const CH_COURS = "cours_v1";            // canaux créés côté natif (MainActivity)
    const CH_SYNC = "sync_v1";
    const SOUND = "alerte.wav";
    const SMALL_ICON = "ic_stat_notify";    // icône cloche (vecteur) créée au build
    const ID_BASE = 1000;                   // ids 1000..1999 = rappels de cours
    const ID_SYNC = 9002;
    const LEAD_MIN = 10;

    let LN = null, PREFS = null;
    let syncShownThisSession = false;
    let lastPushedPending = null;

    // --- outils ---------------------------------------------------------
    function isNative() {
        const c = window.Capacitor;
        return !!(c && typeof c.isNativePlatform === "function" && c.isNativePlatform());
    }
    function plugin(name) {
        const c = window.Capacitor;
        if (!c) return null;
        try { if (c.Plugins && c.Plugins[name]) return c.Plugins[name]; } catch (e) { /* ok */ }
        try { if (typeof c.registerPlugin === "function") return c.registerPlugin(name); } catch (e) { /* ok */ }
        return null;
    }
    function ls(key) { try { const v = localStorage.getItem(key); return v === null ? null : JSON.parse(v); } catch (e) { return null; } }
    const pad = n => String(n).padStart(2, "0");

    async function setPref(key, value) {
        if (!PREFS) return;
        try { await PREFS.set({ key, value: String(value) }); } catch (e) { /* ignoré */ }
    }

    // --- permissions -----------------------------------------------------
    let permPromise = null;
    function ensurePermissions() {            // une seule demande à la fois (évite 2 fenêtres d'autorisation)
        if (!permPromise) permPromise = doEnsurePermissions().finally(() => { permPromise = null; });
        return permPromise;
    }
    async function doEnsurePermissions() {
        if (!LN) return false;
        try {
            let p = await LN.checkPermissions();
            if (p.display !== "granted") p = await LN.requestPermissions();   // Android 13+ : fenêtre d'autorisation
            // Alarmes exactes (Android 12+) : pour que le rappel sonne pile à l'heure
            if (typeof LN.checkExactNotificationSetting === "function" && !ls("sekolify_exact_asked")) {
                const e = await LN.checkExactNotificationSetting();
                if (e && e.exact_alarm === "denied") {
                    localStorage.setItem("sekolify_exact_asked", "true");
                    if (confirm("Pour que les rappels de cours sonnent à l'heure exacte, autorisez « Alarmes et rappels » pour cette application sur l'écran suivant.")) {
                        await LN.changeExactNotificationSetting();
                    }
                }
            }
            return p.display === "granted";
        } catch (e) { return false; }
    }

    // --- rappels de cours --------------------------------------------------
    // même regroupement que l'écran Emploi du temps : 8h + 9h => un seul bloc 08:00–10:00
    function blocksOfDay(timetable, day) {
        const slots = (timetable || []).filter(s => s.day === day).sort((a, b) => a.hour - b.hour);
        const out = [];
        slots.forEach(s => {
            const last = out[out.length - 1];
            if (last && last.class_name === s.class_name && last.subject_name === s.subject_name && last.end === s.hour) last.end = s.hour + 1;
            else out.push({ class_name: s.class_name, subject_name: s.subject_name, start: s.hour, end: s.hour + 1 });
        });
        return out;
    }

    async function clearReminders() {
        const pend = await LN.getPending();
        const old = ((pend && pend.notifications) || [])
            .filter(n => n.id >= ID_BASE && n.id < ID_BASE + 1000).map(n => ({ id: n.id }));
        if (old.length) await LN.cancel({ notifications: old });
    }

    async function scheduleReminders(data) {
        if (!LN) return;
        try {
            if (!(await ensurePermissions())) return;
            await clearReminders();
            const tt = (data && data.timetable) || [];
            const notifications = [];
            for (let day = 0; day < 6; day++) {                       // 0 = lundi … 5 = samedi
                blocksOfDay(tt, day).forEach(b => {
                    const total = b.start * 60 - LEAD_MIN;
                    if (total < 0) return;
                    notifications.push({
                        id: ID_BASE + day * 100 + b.start,
                        title: "Cours dans " + LEAD_MIN + " minutes",
                        body: b.class_name + " · " + b.subject_name + " — " + pad(b.start) + ":00 à " + pad(b.end) + ":00. L'appel est ouvert.",
                        channelId: CH_COURS,
                        smallIcon: SMALL_ICON,
                        sound: SOUND,
                        schedule: { on: { weekday: day + 2, hour: Math.floor(total / 60), minute: total % 60 }, allowWhileIdle: true }
                    });                                                // weekday : 1 = dimanche, 2 = lundi …
                });
            }
            if (notifications.length) await LN.schedule({ notifications });
        } catch (e) { /* ne casse jamais l'app */ }
    }

    // --- état partagé avec le service natif (SyncWatcher) --------------------
    async function pushState(pending, reachable) {
        const ip = ls("sekolify_ip");
        await setPref("bg_ip", ip || "");
        await setPref("bg_port", typeof DISCOVERY_PORT !== "undefined" ? DISCOVERY_PORT : 47831);
        await setPref("bg_pending", pending);
        if (reachable !== undefined) await setPref("bg_last_reachable", reachable ? "1" : "0");
    }

    async function notifySyncNow(pending) {
        if (!LN) return;
        try {
            if (!(await ensurePermissions())) return;
            await LN.schedule({ notifications: [{
                id: ID_SYNC,
                title: "Connecté au serveur de l'école",
                body: pending + " élément(s) non envoyé(s) (notes ou appels). Il est temps de synchroniser avec le PC de l'école.",
                channelId: CH_SYNC,
                smallIcon: SMALL_ICON,
                sound: SOUND
            }] });
        } catch (e) { /* ignoré */ }
    }

    // --- API appelée par app.js ----------------------------------------------
    window.SekNotif = {
        // PC joint + emploi du temps à jour
        onConnected(data, pending) {
            try {
                if (!isNative()) return;
                scheduleReminders(data);
                lastPushedPending = pending;
                pushState(pending, true);                       // le PC répond : évite un doublon côté natif
                if (pending > 0 && !syncShownThisSession) {
                    syncShownThisSession = true;
                    notifySyncNow(pending);
                }
            } catch (e) { /* ignoré */ }
        },
        // PC injoignable : on pourra re-notifier à la prochaine connexion
        onOffline() {
            try {
                syncShownThisSession = false;
                if (isNative()) setPref("bg_last_reachable", "0");
            } catch (e) { /* ignoré */ }
        },
        // nombre d'éléments en attente (notes + appels) (appelé par updateStatus)
        onPending(n) {
            try {
                if (!isNative() || n === lastPushedPending) return;
                lastPushedPending = n;
                if (n === 0) { syncShownThisSession = false; pushState(0, false); }
                else pushState(n);
            } catch (e) { /* ignoré */ }
        },
        // déconnexion du prof : plus de rappels, plus de surveillance
        async onLogout() {
            try {
                if (!isNative()) return;
                syncShownThisSession = false;
                lastPushedPending = 0;
                if (LN) await clearReminders();
                await setPref("bg_pending", 0);
                await setPref("bg_ip", "");
                await setPref("bg_last_reachable", "0");
            } catch (e) { /* ignoré */ }
        }
    };

    // --- démarrage -------------------------------------------------------------
    document.addEventListener("DOMContentLoaded", async () => {
        try {
            if (!isNative()) return;
            LN = plugin("LocalNotifications");
            PREFS = plugin("Preferences");
            if (!ls("sekolify_token")) return;                  // pas encore connecté : rien à planifier
            const cached = ls("sekolify_data");
            if (cached) await scheduleReminders(cached);        // rappels dispo même sans réseau
            const dirty = ls("sekolify_dirty") || {};
            lastPushedPending = Object.keys(dirty).length;
            await pushState(lastPushedPending);
        } catch (e) { /* ignoré */ }
    });
})();
